import React, { useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.js";
import { getManagerId } from "../Utils/Common";
import projectDetailsJson from "./projectDetailsJson.js";

export default class ViewProjects extends React.Component {
  state = {
    projects: ["Blank Project"],
    selectedProject: "",
    dropdownLoad: false,
  };

  render() {
    const manager = getManagerId();
    {
      if (!this.state.dropdownLoad) {
        this.setState({ dropdownLoad: true });
        axios
          .get(`http://we759.mocklab.io/projects/${manager}`)
          .then((response) => {
            this.setState({ projects: response.data });
            this.setState({ selectedProject: response.data[0] });
            console.log("response.data...", response.data);
          })
          .catch((error) => {
            this.setState({ dropdownLoad: false });
            console.log("exception while getting users");
          });
      }
    }

    const selectProject = (e) => {
      this.setState({ selectedProject: e.target.id });
    };

    return (
      <div class="jumbotron card container">
        <div class="dropdown">
          <button
            class="btn btn-primary  btn-lg dropdown-toggle"
            type="button"
            id="dropdownMenu2"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >
            {this.state.selectedProject === ""
              ? "Select"
              : this.state.selectedProject}
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
            {this.state.projects.map((project) => {
              return (
                <button
                  class="dropdown-item"
                  id={project}
                  onClick={(event) => selectProject(event)}
                  type="button"
                >
                  {project}
                </button>
              );
            })}
          </div>
        </div>
        <div></div>
        <DisplayProject />
      </div>
    );
  }
}

export function DisplayProject(props) {
  return (
    <div>
      <table class="table table-bordered table-secondary">
        <thead class="thead-dark">
          <tr>
            <th scope="col">Asserts</th>
            <th scope="col">Complex</th>
            <th scope="col">Medium</th>
            <th scope="col">Simple</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">$76</th>
            <td>$98</td>
            <td>$28</td>
            <td>$73</td>
          </tr>
          <tr>
            <th scope="row">$85</th>
            <td>$08</td>
            <td>$68</td>
            <td>$86</td>
          </tr>
          <tr>
            <th scope="row">$67</th>
            <td colspan="2">$68</td>
            <td>$95</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
