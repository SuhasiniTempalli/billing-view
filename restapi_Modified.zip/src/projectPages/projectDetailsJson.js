export const data={
  "Simple": [
    {
      "field1": "Sample Simple details",
      "field2": "2"
    }
  ],
  "Assets": [
    {
      "field1": "Sample Asset details",
      "field2": "90"
    }
  ],
  "Complex": [
    {
      "field1": "Sample Complex details",
      "field2": "76"
    }
  ],
  "Medium": [
    {
      "field1": "Sample Medium details",
      "field2": "86"
    }
  ]
}
export default data;