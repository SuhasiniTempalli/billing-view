import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import logo from "./logo.svg";
import loginimage from "./images/loginimage.jpg";
import ProjectSetup from "./ProjectSetup";
import History from "./History.js";
import Routes from "./Routes.js";
import RegisterScreen from "./RegisterScreen";
import axios from "axios";
import { ase64 } from "base64-js";
import signin from "./css/signin.css";

var CryptoJS = require("crypto-js");
class LoginScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      ManagerId: "",
      Password: "",
      RememberMe: false,
    };
  }
  handleManagerId = (event) => {
    this.setState({ ManagerId: event.target.value });
  };
  handlePassword = (event) => {
    
    this.setState({ Password: event.target.value });
  };
  handleRememberMe = (event) => {
    const input = event.target;
    const value = input.type === "checkbox" ? input.checked : input.value;

    this.setState({ [input.name]: value });
  };
  handleLogin = (event) => {
    event.preventDefault();
    const { user, rememberMe } = this.state;
    localStorage.setItem('rememberMe', rememberMe);
    localStorage.setItem('user', rememberMe ? user : '');
 
  };

  componentDidMount() {
    const rememberMe = localStorage.getItem('rememberMe') === 'true';
    const user = rememberMe ? localStorage.getItem('user') : '';
    this.setState({ user, rememberMe });
    axios
      .get(`http://l9ro2.mocklab.io/login`)
      .then((res) => {
        const statusDetails = res.status;
        console.log(statusDetails);
      });
  }
  render() {
    return (
      <React.Fragment>
        <form >
          <div class="card-body">
            <div class="row d-flex">
              <div class="col-lg-6">
                <div class="card1 pb-5">
                  <div class="row">
                    <img src={logo} class="logo" />
                  </div>
                  
                </div>
              </div>
              <div class="card1 pb-5">
                <div class="card2 card border-0 px-4 py-5">
                  <div class="row mb-4 px-3"> 
                    <h6 class="mb-0 mr-4 mt-2">Sign in with</h6>
                  </div>

                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">ManagerId</h6>
                    </label>
                    <input
                      class="mb-4"
                      type="number"
                      name="ManagerId"
                      placeholder="Enter a valid ManagerId"
                      onChange={this.ManagerId}
                    />
                  </div>
                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">Password</h6>
                    </label>
                    <input
                      type="password"
                      name="password"
                      placeholder="Enter password"
                      onChange={this.Password}
                    />
                  </div>
                  <div class="row px-3 mb-4">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        id="chk1"
                        type="checkbox"
                        name="chk"
                        class="custom-control-input"
                        onChange={this.RememberMe}
                      />
                      <label for="chk1" class="custom-control-label text-sm">
                        Remember me
                      </label>
                    </div>
                    <a href="#" class="ml-auto mb-0 text-sm">
                      Forgot Password?
                    </a>
                  </div>

                  <div class="row mb-3 px-3">
                    <button
                      type="submit"
                      class="btn btn-blue text-center"
                      onClick={this.login}
                    >
                      Login
                    </button>
                  </div>

                  <div class="row mb-4 px-3">
                    <button
                      type="submit"
                      class="btn btn-blue text-center"
                      onClick={() => History.push("/register")}
                    >
                      Register
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div class="bg-blue py-4">
              <div class="row px-3">
                <small class="ml-4 ml-sm-5 mb-2">
                  Copyright &copy; 2019. All rights reserved.
                </small>
                <div class="social-contact ml-4 ml-sm-auto">
                  <span class="fa fa-facebook mr-4 text-sm"></span>
                  <span class="fa fa-google-plus mr-4 text-sm"></span>
                  <span class="fa fa-linkedin mr-4 text-sm"></span>
                  <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span>
                </div>
              </div>
            </div>
          </div>
        </form>
      </React.Fragment>
    );
  }
}
export default LoginScreen;
