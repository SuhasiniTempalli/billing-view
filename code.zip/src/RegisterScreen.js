import React, { Component } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Signin from "./css/signin.css";
import logo from "./logo.svg";
import loginimage from "./images/loginimage.jpg";
import axios from 'axios';

class RegisterScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Name: "",
      EmailId: "",
      ManagerId: "",
      Password: "",
      PlaceOfBirth: "",
    };
   
  }

  handleName = event => {
    this.setState({ Name: event.target.value });
  }
  handleEmailId = event => {
    this.setState({ EmailId: event.target.value });
  }
  handleManagerID = event => {
    this.setState({ ManagerId: event.target.value });
  }

  handlePassword = event => {
    this.setState({ Password: event.target.value });
  }
  handlePlaceOfBirth = event => {
    this.setState({ PlaceOfBirth: event.target.value });
  }
  handleRegister = event => {
    event.preventDefault();

    const regdetails = {
      Name: this.state.Name,
      EmailId:this.state.EmailId,
      ManagerId:this.state.ManagerId,
      Password:this.state.Password,
      PlaceOfBirth:this.state.PlaceOfBirth
    };

    axios.post(`https://jsonplaceholder.typicode.com/users`, { regdetails })
      .then(res => {
        console.log(res);
        console.log(res.data);
        console.log(regdetails)
      })
  }

  

  render() {
    return (
      <React.Fragment>
        <div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
          <div class="card card0 border-0">
            <div class="row d-flex">
              <div class="col-lg-6">
                <div class="card1 pb-5">
                  <div class="row">
                    <img src={logo} class="logo" />
                  </div>
                  <div class="row px-3 justify-content-center mt-4 mb-5 border-line">
                    <img src={loginimage} class="image" />
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="card2 card border-0 px-4 py-5">
                  <div class="row mb-4 px-3">
                    <h6 class="mb-0 mr-4 mt-2">Register with</h6>
                  </div>
                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">Name</h6>
                    </label>
                    <input
                      class="mb-4"
                      type="text"
                      name="email"
                      placeholder="Enter Name"
                      onChange={this.handleName}
                    />
                  </div>
                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">EmailId</h6>
                    </label>
                    <input
                      class="mb-4"
                      type="text"
                      name="email"
                      placeholder="Enter a valid Email Address"
                      onChange={this.handleEmailId}
                    />
                  </div>
                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">ManagerId</h6>
                    </label>
                    <input
                      class="mb-4"
                      type="number"
                      name="email"
                      placeholder="Enter a valid ManagerId"
                      onChange={this.handleManagerID}
                    />
                  </div>
                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">Password</h6>
                    </label>
                    <input
                      type="password"
                      name="password"
                      placeholder="Enter password"
                      onChange={this.handlePassword}
                    />
                  </div>
                  <div class="row px-3">
                    <label class="mb-1">
                      <h6 class="mb-0 text-sm">PlaceOfBirth</h6>
                    </label>
                    <input
                      type="text"
                      name="placeOfBirth"
                      placeholder="Enter PlaceOfBirth"
                      onChange={this.handlePlaceOfBirth}
                    />
                  </div>
                  <div class="row px-3 mb-4">
                    <div class="custom-control custom-checkbox custom-control-inline">
                      <input
                        id="chk1"
                        type="checkbox"
                        name="chk"
                        class="custom-control-input"
                      />
                      <label for="chk1" class="custom-control-label text-sm">
                        Remember me
                      </label>
                    </div>
                    <a href="#" class="ml-auto mb-0 text-sm">
                      Forgot Password?
                    </a>
                  </div>
                  <div class="row mb-3 px-3">
                    <button
                      type="submit"
                      class="btn btn-blue text-center"
                      onClick={this.handleRegister}
                    >
                      Register
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div class="bg-blue py-4">
              <div class="row px-3">
                <small class="ml-4 ml-sm-5 mb-2">
                  Copyright &copy; 2019. All rights reserved.
                </small>
                <div class="social-contact ml-4 ml-sm-auto">
                  <span class="fa fa-facebook mr-4 text-sm"></span>
                  <span class="fa fa-google-plus mr-4 text-sm"></span>
                  <span class="fa fa-linkedin mr-4 text-sm"></span>
                  <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
export default RegisterScreen;
