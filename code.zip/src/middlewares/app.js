import { apiRequest } from "../actions/api";
import { LOGIN } from "../actions/auth";

const SERVER_URL = 'http://l9ro2.mocklab.io/login';

export const appMiddleware = () => next => action => {
  next(action);
  switch (action.type) {
    case LOGIN: {
      next(
        apiRequest({
          url: SERVER_URL,
          method: "POST"
        })
      );
      break;
    }
    default:
      break;
  }

};