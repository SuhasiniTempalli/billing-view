import React from 'react';
import './App.css';
import LoginScreen from './LoginScreen.js';
import Routes from './Routes.js';
import RegisterScreen from "./RegisterScreen";

function App() {
  return (
    <div className="App">
      
      <Routes/>
</div>
  );
}

export default App;