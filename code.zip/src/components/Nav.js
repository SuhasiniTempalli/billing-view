import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";

import { logout } from "../actions/auth";

class NavBar extends Component {
  render() {
    return (
      <nav position="static" style={{ display: "flex" }}>
        <form>
          <h1 variant="h6">My App</h1>
          <div style={{ marginLeft: "auto" }}>
            {this.props.isAuthUser ? (
              <>
                <Link to="/home">
                  <button color="inherit">Home</button>
                </Link>
                <Link to="/my-account">
                  <button color="inherit">My Account</button>
                </Link>
                <button color="inherit" onClick={this.props.logout}>
                  Logout
                </button>
              </>
            ) : (
              <Link to="/login">
                <button color="inherit">Login</button>
              </Link>
            )}
          </div>
        </form>
      </nav>
    );
  }
}

export default connect(({ isAuthUser }) => ({ isAuthUser }), { logout })(
  NavBar
);