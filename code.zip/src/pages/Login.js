import React, { useState } from "react";

import { connect } from "react-redux";
import { login } from "../actions/auth";


export default connect(null, { login })(props => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submitForm = () => {
    if (email === "" || password === "") {
      setError("Fields are required");
      return;
    }
    props.login({ email, password });
    console.log('end of submit form');
  };
  return (
    <form>
      <input
        label="Email"
        variant="outlined"
        className="form-input"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />
      <input
        label="Password"
        variant="outlined"
        className="form-input"
        type="password"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />
      <button
        variant="contained"
        color="primary"
        className="form-input"
        size="large"
        onClick={submitForm}
      >
        Login
      </button>
      {(props.error || error) && (
        <a>
          {props.error || error}
        </a>
      )}
    </form>
  );
});