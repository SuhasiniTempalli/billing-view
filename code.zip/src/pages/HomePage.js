import React from "react";

export default props => (
  <div>
    <p>This is the Home Page.</p>
    <p>Go to Search Page and search some images.</p>
  </div>
);